from flask import Flask, request, jsonify, send_file
import cv2
import numpy as np
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'Media'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def save_uploaded_images(files):

    filepaths = []
    for file in files:
        if file.filename:
            path = os.path.join(UPLOAD_FOLDER, file.filename)
            file.save(path)
            filepaths.append(path)
    return filepaths


def detect_and_match_features(img1, img2, method='ORB'):

    if method == 'ORB':
        detector = cv2.ORB_create()
        matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    elif method == 'SIFT':
        detector = cv2.SIFT_create()
        matcher = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)
    elif method == 'SURF':
        detector = cv2.xfeatures2d.SURF_create()
        matcher = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)
    else:
        return None, None, None

    keypoints1, descriptors1 = detector.detectAndCompute(img1, None)
    keypoints2, descriptors2 = detector.detectAndCompute(img2, None)

    if descriptors1 is None or descriptors2 is None:
        return None, None, None

    matches = sorted(matcher.match(descriptors1, descriptors2), key=lambda x: x.distance)
    return keypoints1, keypoints2, matches


def stitch_images_with_homography(image_files, feature_method='ORB'):

    if len(image_files) < 2:
        return None, "At least two images are required for stitching."

    img1 = cv2.imread(image_files[0])
    for i in range(1, len(image_files)):
        img2 = cv2.imread(image_files[i])

        keypoints1, keypoints2, matches = detect_and_match_features(img1, img2, feature_method)

        if keypoints1 is None or keypoints2 is None or len(matches) < 10:
            return None, "Not enough feature matches to align images."

        src_pts = np.float32([keypoints1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
        dst_pts = np.float32([keypoints2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
        H, _ = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)

        if H is None:
            return None, "Homography computation failed."


        height, width, _ = img2.shape
        img1_warped = cv2.warpPerspective(img1, H, (width * 2, height))
        img1_warped[0:height, 0:width] = img2
        img1 = img1_warped

    stitched_path = os.path.join(UPLOAD_FOLDER, 'stitched.jpg')
    cv2.imwrite(stitched_path, img1)
    return stitched_path, None


@app.route('/upload_images', methods=['POST'])
def upload_images():

    if 'images' not in request.files:
        return jsonify({'error': 'No images provided'}), 400

    files = request.files.getlist('images')
    filepaths = save_uploaded_images(files)
    return jsonify({'message': 'Images uploaded successfully', 'files': filepaths})


@app.route('/stitch_images', methods=['GET'])
def stitch_images():

    image_files = [os.path.join(UPLOAD_FOLDER, f) for f in os.listdir(UPLOAD_FOLDER) if f.endswith(('.png', '.jpg', '.jpeg'))]

    stitched_path, error = stitch_images_with_homography(image_files, feature_method='ORB')
    if error:
        return jsonify({'error': error}), 400

    return send_file(stitched_path, mimetype='image/jpeg')


@app.route('/roi_selection', methods=['POST'])
def roi_selection():

    data = request.json
    x, y, width, height = data.get('x'), data.get('y'), data.get('width'), data.get('height')

    image_path = os.path.join(UPLOAD_FOLDER, 'stitched.jpg')
    image = cv2.imread(image_path)

    if image is None:
        return jsonify({'error': 'No stitched image found'}), 400

    roi = image[y:y + height, x:x + width]
    roi_path = os.path.join(UPLOAD_FOLDER, 'roi.jpg')
    cv2.imwrite(roi_path, roi)

    return send_file(roi_path, mimetype='image/jpeg')


@app.route('/zoom', methods=['POST'])
def zoom():

    data = request.json
    scale = data.get('scale', 10)  # Default to 10X zoom

    roi_path = os.path.join(UPLOAD_FOLDER, 'roi.jpg')
    roi = cv2.imread(roi_path)

    if roi is None:
        return jsonify({'error': 'No ROI image found'}), 400

    zoomed = cv2.resize(roi, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    zoomed_path = os.path.join(UPLOAD_FOLDER, 'zoomed.jpg')
    cv2.imwrite(zoomed_path, zoomed)

    return send_file(zoomed_path, mimetype='image/jpeg')


@app.route('/auto_focus', methods=['GET'])
def auto_focus():

    stitched_path = os.path.join(UPLOAD_FOLDER, 'stitched.jpg')
    image = cv2.imread(stitched_path)

    if image is None:
        return jsonify({'error': 'No stitched image found'}), 400


    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharpened = cv2.filter2D(image, -1, kernel)

    sharpened_path = os.path.join(UPLOAD_FOLDER, 'sharpened.jpg')
    cv2.imwrite(sharpened_path, sharpened)

    return send_file(sharpened_path, mimetype='image/jpeg')


@app.route('/')
def home():
    return "Flask API for Microscope Image Processing is Running!"


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
